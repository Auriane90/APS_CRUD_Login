import self as self
from django.shortcuts import render, get_object_or_404, HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import Activity, User
from django.shortcuts import redirect
from django.contrib import messages
from .forms import ActivityForms


def login_user(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        users = User.objects.all()

        for user in users:
            if user.user_email == email and user.user_password == password:
                return redirect('Index', id=user.user_id)
    return render(request, 'login.html')


def index(request, id):
    context = {}
    context["dataset"] = Activity.objects.filter(user_id=id)
    context["id"] = id
    return render(request, 'index.html', context)


def createActivity(request, id):
    context = {}

    form = ActivityForms(request.POST or None)
    if form.is_valid():
        form.cleaned_data['user_id'] = id
        form.save()
        messages.success(request, 'Form submission successful')
        return redirect('Index', id=id)
    context['form'] = form
    return render(request, 'createActivity.html', context)


def updateActivity(request, id):
    context = {}

    # fetch the object related to passed id
    obj = get_object_or_404(Activity, activity_id=id)
    obj2 = Activity.objects.filter(activity_id=id).values('user_id')
    user_id_act = 0

    for ob in obj2:
        user_id_act = ob['user_id']

    # pass the object as instance in form
    form = ActivityForms(request.POST or None, instance=obj)

    # save the data from the form and
    # redirect to detail_view
    if form.is_valid():
        form.save()
        return redirect('Index', id=user_id_act)

    # add form dictionary to context
    context["form"] = form

    return render(request, "updateActivity.html", context)


def deleteActivity(request, id):
    context = {}

    # fetch the object related to passed id
    obj = get_object_or_404(Activity, activity_id=id)
    obj2 = Activity.objects.filter(activity_id=id).values('user_id')
    user_id_act = 0

    for ob in obj2:
        user_id_act = ob['user_id']

    context["id"] = user_id_act

    if request.method == "POST":
        # delete object
        obj.delete()
        # after deleting redirect to
        # home page
        return redirect('Index', id=user_id_act)

    return render(request, "deleteActivity.html", context)
