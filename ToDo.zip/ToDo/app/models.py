from django.db import models


class User(models.Model):
    user_id = models.AutoField(primary_key=True)
    user_name = models.CharField(unique=True, max_length=40)
    user_email = models.CharField(unique=True, max_length=255)
    user_password = models.CharField(max_length=8)


class Activity(models.Model):
    activity_id = models.AutoField(primary_key=True)
    activity_description = models.CharField(max_length=255)
    user_id = models.ForeignKey(User, models.DO_NOTHING, db_column='user_id')

