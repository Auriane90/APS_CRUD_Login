from django import forms
from .models import Activity


class ActivityForms(forms.ModelForm):
    class Meta:
        model = Activity

        fields = [
            "activity_description",
            "user_id",
        ]

        widgets = {
            'activity_description': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 255}),
            'user_id': forms.TextInput(attrs={'type': 'hidden', 'value': '1'}),
        }

        erro_message = {
            'activity_description': {
                'required': 'Esse campo e obrigatorio'
            }
        }
