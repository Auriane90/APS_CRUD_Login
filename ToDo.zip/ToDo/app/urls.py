from django.urls import path
from . import views

urlpatterns = [
    path('listaActivity/<id>', views.index, name='Index'),
    path('', views.login_user, name='login'),
    path('createActivity/<id>', views.createActivity, name='createActivity'),
    path('updateActivity/<id>', views.updateActivity, name='updateActivity'),
    path('deleteActivity/<id>', views.deleteActivity, name='deleteActivity'),
]
